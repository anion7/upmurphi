suggested execution:

../../bin/upmc genlinear.pddl genproblinear.pddl --custom 1 5 2 
./genlinear_planner

