suggested execution:

../../bin/upmc planetary_lander.pddl planetary_lander_problem.pddl
./planetary_lander_planner

