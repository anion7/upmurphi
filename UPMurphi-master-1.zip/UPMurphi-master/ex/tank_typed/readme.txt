This is a typed version of the "Tanks and a Bucket (Toricelli's formula)" domain,
taken from the VAL validator package:
https://github.com/KCL-Planning/VAL/tree/master/domainsWithEventsAndProcesses/Tanks%20and%20a%20Bucket%20%28Toricelli%27s%20formula%29

suggested execution:

../../bin/upmc tank_domain.pddl tank_problem.pddl --custom 0.5 5 2 
./tank_domain_planner -format:pddlvv 

